struct sysinfo {
	unsigned int memfree;   // amount of free memory, in KB
	unsigned int numproc;   // number of processes in the system
};
